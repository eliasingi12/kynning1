//
//  File.cpp
//  kynning1
//
//  Created by ElÌas Ingi ElÌasson on 11/30/15.
//  Copyright (c) 2015 ElÌas Ingi ElÌasson. All rights reserved.
//
#include "data_layer.h"
#include "domain_layer.h"
#include <string>
#include <list>
#include <iostream>
#include <fstream>
#include <algorithm>
using namespace std;

// over writing list.sort()
bool person::operator< (const person& r_n)
{
	
	if (laast_name == r_n.laast_name)
		return name < r_n.name;
	else if (name == r_n.name)
		return middle_name < r_n.middle_name;
    
	return laast_name < r_n.laast_name;
}

computer_sciecentst::computer_sciecentst()
{
	person sciecentst;
    
	ifstream file;
	file.open("person.txt");
    
	string name = "";
	string middle_name = "";
	string laast_name = "";
	char gender = ' ';
	int birth_year = 0;
	int year_of_death = 0;
	// read line by line
	while (file >> name >> middle_name >> laast_name >> gender >> birth_year >> year_of_death)
	{
		sciecentst.name = name;
		if (middle_name == "-")
			middle_name = "";
		sciecentst.middle_name = middle_name;
		sciecentst.laast_name = laast_name;
		sciecentst.gender = gender;
		sciecentst.birth_year = birth_year;
		sciecentst.year_of_death = year_of_death;
		
		names.push_back(sciecentst);
	}
	file.close();
    
	
}


void computer_sciecentst::write_person(string name, string middle_name, string laast_name, char gender, int birth_year, int year_of_death)
{
    ofstream file;
    
	file.open("person.txt", ios_base::app);
	// append to file
	file << "\n" << name << " " << middle_name << " " << laast_name << " " << gender << " " << birth_year << " " << year_of_death;
	file.close();
    
    
}



list<person> computer_sciecentst::get_list()
{
	return names;
}

computer_sciecentst::~computer_sciecentst()
{
	names.clear();
}
