//
//  File.h
//  kynning1
//
//  Created by Elías Ingi Elíasson on 11/30/15.
//  Copyright (c) 2015 Elías Ingi Elíasson. All rights reserved.
//



#ifndef data_layer_Header_h
#define data_layer_Header_h

#include <iostream>
#include <string>
#include <list>
using namespace std;

struct person
{
	string name;
    string middle_name;
	string laast_name;
	char gender;
	int birth_year;
	int year_of_death;
	// over writing list.sort()
	bool operator <(const person& r_n);
};


class computer_sciecentst
{
public:
	computer_sciecentst();
	void write_person(string name, string middle_name, string laast_name, char gender, int birth_year, int year_of_death);
    list<person> get_list();
	~computer_sciecentst();
    
private:
	list<person> names;
};



#endif