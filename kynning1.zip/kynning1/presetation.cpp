//
//  File3.cpp
//  kynning1
//
//  Created by Elías Ingi Elíasson on 12/1/15.
//  Copyright (c) 2015 Elías Ingi Elíasson. All rights reserved.
//

#include "presentation_layer.h"
#include "domain_layer.h"
#include "data_layer.h"
#include <iostream>
#include <string>
#include <list>
#include <string.h>
#include <stdio.h>
#include <ctype.h>
using namespace std;

main_program::main_program()
{
	sci.names_dsc();
	
}

bool main_program::legal_choice(int num)
{
    if (num <= 1 && num >= 11)
    {
        eror = "Choose a legal number";
        return false;
    }
    
    return true;
}


bool main_program::legal_name(string name)
{
    char name_char_array[100];
    strcpy(name_char_array, name.c_str());
    bool legal = true;
    
    for(int i= 0; i<name.length(); i++)
    {
        if (!isalpha(name_char_array[i]))
        {
            eror = "Name cannot contain numbers";
            legal = false;
        }
        
        if (!isupper(name_char_array[0]))
        {
            eror = "Name must begin with uppercase letter";
            legal = false;
            
        }
        
        if (!isupper(name_char_array[i]) && i <= 1)
        {
            eror = "Must be a lower case letter";
            legal = false;
            
        }
        
        if (!legal)
            break;
        
    }
    
    return legal;
}


bool main_program::legal_gender(char gen)
{
    char possiple_genders[3] = {'m','f','t'};
    
    bool legal = false;
    
    for(int i = 0; i < 3; i++)
    {
        if (gen == possiple_genders[i])
        {
            legal = true;
        }
    }
    
    return legal;
}


bool main_program::legal_year(string year)
{
    if (year.length() != 4)
    {
        return false;
    }
    
    char year_char_array[100];
    strcpy(year_char_array, year.c_str());
    bool legal = true;
    
    for(int i = 0; i < year.length(); i++)
    {
        if (!isdigit(year_char_array[i]))
        {
            legal = false;
        }
        
        
        if (!legal)
            break;
        
    }
    
    return legal;
}

void main_program::add_scientist(string name, string middle_name, string laast_name, char gender, int birth_year, int year_of_death)
{
    sci.add_name(name, middle_name, laast_name, gender, birth_year, year_of_death);
}

void main_program::names_asc()
{
    sci.names_asc();
}

void main_program::names_dsc()
{
    sci.names_dsc();
}

list<string> main_program::print_scientist()
{
    list<string> scientis;
    string tmp = "";
    list<person>::iterator i;
    list<person> names;
    names = sci.get_names();
	for (i = names.begin(); i != names.end(); i++)
    {
        tmp = i->name + " " + i->middle_name + " " + i->laast_name + " " + i->gender + " " + to_string(i->birth_year) + " " + to_string(i->year_of_death);
        scientis.push_back(tmp);
    }
    return scientis;
}


bool legal_not_defined(string s)
{
    return (s.length() == 1 && s == "-");
}

string main_program::info()
{
    string mes = "";
    mes += "Press 1 to sort by last name asc \n";
	mes += "Press 2 to to sort by last name dsc \n";
	mes += "Press 3 to search by first name \n";
	mes += "Press 4 to search by middle name \n";
	mes += "Press 5 to search by last name \n";
	mes += "Press 6 to search by gender \n";
	mes += "Press 7 to search by year of birth \n";
	mes += "Press 8 to search by year of death \n";
	mes += "Press 9 to input a new person \n";
	mes += "Press 10 to quit \n ";
    
	return mes;
}

string main_program::get_error()
{
	return eror;
}

errors main_program::run(int x)
{
	char g = ' ';
	errors err;
	
	switch (x)
	{
        case 1:
            sci.names_asc();
            err.should_print = true;
            break;
        case 2:
            sci.names_dsc();
            err.should_print = true;
            break;
        case 3:
            err.search = sci.search_name(err.search_string, 1);
            err.should_print = true;
            break;
        case 4:
            err.search = sci.search_name(err.search_string, 2);
            err.should_print = true;
            break;
        case 5:
            err.search = sci.search_name(err.search_string, 3);
            err.should_print = true;
            break;
        case 6:
            g = err.search_string[0];
            err.search = sci.search_gender(g);
            err.should_print = true;
            break;
        case 7:
            err.search = sci.search_year(err.search_string, true);
            err.should_print = true;
            break;
        case 8:
            err.search = sci.search_year(err.search_string, false);
            err.should_print = true;
            break;
        case 9:
            err.add_scientist = true;
            break;
        case 10:
            err.is_error = false;
            break;
        default:
            break;
            
	}
    
	return err;
}









