//
//  File2.h
//  kynning1
//
//  Created by Elías Ingi Elíasson on 12/1/15.
//  Copyright (c) 2015 Elías Ingi Elíasson. All rights reserved.
//

#ifndef __kynning1__domain_layer__
#define __kynning1__domain_layer__

#include "data_layer.h"
#include <iostream>
#include <string>
#include <list>
using namespace std;

class domain_layer
{
public:
    domain_layer();
    list <person> search_person(string s);
    void order_list();
    void names_asc();
    void names_dsc();
    list<person> get_names();
    list<person> search_name(string s, int name_number);
    list<person> search_year(string s, bool is_first_year);
    list<person> search_gender(char g);
    void add_name(string name, string middle_name, string laast_name, char gender, int birth_year, int year_of_death);
    
    //~domain_layer();
    
private:
    list<person> names;
    bool is_asc = true;
};

#endif /* defined(__kynning1__domain_layer__) */
