//
//  File2.cpp
//  kynning1
//
//  Created by Elías Ingi Elíasson on 12/1/15.
//  Copyright (c) 2015 Elías Ingi Elíasson. All rights reserved.
//

#include "domain_layer.h"
#include "data_layer.h"
#include <iostream>
using namespace std;

domain_layer::domain_layer()
{
    computer_sciecentst c;
    names = c.get_list();
    order_list();
    is_asc = true;
}

void domain_layer::names_asc()
{
	if (!is_asc)
	{
		names.reverse();
		is_asc = false;
	}
}

void domain_layer::names_dsc()
{
	if (is_asc)
	{
		names.reverse();
		is_asc = true;
	}
}

void domain_layer::order_list()
{
	names.sort();
}

list<person> domain_layer::search_name(string s, int name_number)
{
    list<person> search_list;
    
    int name_length = 0;
    bool has_added = false;
    string name = "";
    list<person>::iterator i;
	for (i = names.begin(); i != names.end(); i++)
    {
        if (name_number == 1)
            name = i->name;
        else if(name_number == 2)
            name = i->middle_name;
        else
            name = i->laast_name;
        name_length = name.length();
        has_added = false;
        
  		for (int j = 0; j < name_length - s.length(); j++)
		{
			cout << name.substr(j, s.length()) << endl;
			if (name.substr(j, s.length()) == s && !has_added)
			{
				person sciecentst;
                
				sciecentst.name = i->name;
				sciecentst.middle_name = i->middle_name;
				sciecentst.laast_name = i->laast_name;
				sciecentst.gender = i->gender;
				sciecentst.birth_year = i->birth_year;
				sciecentst.year_of_death = i->year_of_death;
				search_list.push_back(sciecentst);
			}
            
		}
	}
	return search_list;
}

list<person> domain_layer::search_year(string s, bool is_birth_year)
{
	list<person> search_list;
    
	string year = "";
	bool has_added = false;
	list<person>::iterator i;
	for (i = names.begin(); i != names.end(); i++)
	{
		if (is_birth_year)
			year = to_string(i->birth_year);
		else
			year = to_string(i->year_of_death);
		has_added = false;
        
		for (int j = 0; j < 4 - s.length(); j++)
		{
			cout << year.substr(j, s.length()) << endl;
            
			if (year.substr(j, s.length()) == s && !has_added)
			{
				person sciecentst;
                
				sciecentst.name = i->name;
                sciecentst.middle_name = i->middle_name;
				sciecentst.laast_name = i->laast_name;
				sciecentst.gender = i->gender;
				sciecentst.birth_year = i->birth_year;
				sciecentst.year_of_death = i->year_of_death;
				search_list.push_back(sciecentst);
			}
            
		}
	}
	return search_list;
    
}

list<person>domain_layer::search_gender(char g)
{
    list<person> search_list;
    list<person>::iterator i;
	for (i = names.begin(); i != names.end(); i++)
    {
        if (i->gender == g)
        {
            
            person sciecentst;
            
            sciecentst.name = i->name;
            sciecentst.middle_name = i->middle_name;
            sciecentst.laast_name = i->laast_name;
            sciecentst.gender = i->gender;
            sciecentst.birth_year = i->birth_year;
            sciecentst.year_of_death = i->year_of_death;
            
            search_list.push_back(sciecentst);
        }
        
    }
    return search_list;
}

void domain_layer::add_name(string name, string middle_name, string laast_name, char gender, int birth_year, int year_of_death)
{
    person sciecentst;
    computer_sciecentst w;
    
	sciecentst.name = name;
    sciecentst.middle_name = middle_name;
	sciecentst.laast_name = laast_name;
	sciecentst.gender = gender;
	sciecentst.birth_year = birth_year;
	sciecentst.year_of_death = year_of_death;
    
	names.push_back(sciecentst);
    w.write_person(name, middle_name, laast_name, gender, birth_year, year_of_death);
}

list<person> domain_layer::get_names()
{
	return names;
}














