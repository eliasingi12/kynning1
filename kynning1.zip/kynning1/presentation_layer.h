//
//  File3.h
//  kynning1
//
//  Created by Elías Ingi Elíasson on 12/1/15.
//  Copyright (c) 2015 Elías Ingi Elíasson. All rights reserved.
//

#ifndef __kynning1__presentation_layer__
#define __kynning1__presentation_layer__

#include <iostream>
#include <string>
#include "domain_layer.h"
#include <list>
using namespace std;

struct errors
{
    bool is_error;
    string error;
    bool should_print = false;
    bool search_print = false;
    bool add_scientist = false;
    bool should_search = false;
    list<person> search;
    string search_string;
};

class main_program
{
public:
    main_program();
    bool legal_choice(int num);
    bool legal_name(string name);
    bool legal_year(string year);
    bool legal_not_defined(string s);
    bool legal_gender(char gen);
    string get_error();
    void add_scientist(string name, string middle_name, string laast_name, char gender, int birth_year, int year_of_death);
    string info();
    errors run(int x);
    void names_asc();
    void names_dsc();
    list<string> print_scientist();

private:
    domain_layer sci;
    string eror;
    bool is_birth_year_serch;
    bool quit_program = false;
};

#endif /* defined(__kynning1__presentation_layer__) */
