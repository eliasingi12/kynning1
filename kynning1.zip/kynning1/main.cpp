//
//  main.cpp
//  kynning1
//
//  Created by Elías Ingi Elíasson on 11/30/15.
//  Copyright (c) 2015 Elías Ingi Elíasson. All rights reserved.
//

#include <iostream>
#include <list>
#include <string>
#include "presentation_layer.h"
using namespace std;

void print_scientist(main_program a);
void print_search(errors a);
void input_person(string &f, string &m, string &l, char &g, string &y_o_b, string &y_o_d, main_program x);
void input_search(string &s);

int main(int argc, const char * argv[])
{
    string first_name;
	string middle_name;
	string last_name;
	char gender;
	string year_of_birth;
	string year_of_death;
	int choice = 0;
    string search_string;
	main_program x;
    
	errors err;
    
	while (err.is_error)
	{
		cout << x.info() << endl;
		err.should_print = false;
        
		do
		{
			cout << x.get_error() << endl;
			cin >> choice;
            
		} while (!(x.legal_choice(choice)));
        
        
		err = x.run(choice);
        
		cout << err.error << endl;
        
		if (err.add_scientist)
		{
			input_person(first_name, middle_name, last_name, gender, year_of_birth, year_of_death,x);
			x.add_scientist(first_name, middle_name, last_name, gender, stoi(year_of_birth), stoi(year_of_death));
		}
        
        
		if(err.should_print)
		    print_scientist(x);
        
        
        if (err.should_search)
        {
            input_search(search_string);
            err.search_string = search_string;
            print_search(err);
        }
        
	}
    
    
	return 0;
}

void print_scientist(main_program x)
{
	list<string> print = x.print_scientist();
	list<string>::iterator i;
    
	for (i = print.begin(); i != print.end(); i++)
	{
		cout << *i << endl;
	}
}

void print_search(errors a)
{
	list<person>::iterator i;
	for (i = a.search.begin(); i != a.search.end(); i++)
	{
		cout << i->name << " " << i->middle_name << " " << i->laast_name << " " << i->birth_year << " " << i->year_of_death << endl;
	}
}

void input_person(string &f, string &m, string &l, char &g, string &y_o_b, string &y_o_d, main_program x)
{
	do
	{
        cout << x.get_error() << endl;
		cout << "Enter a first name: " << endl;
		cin >> f;
	} while (x.legal_name(f));
    
	do
	{
        cout << x.get_error() << endl;
		cout << "Enter a middle name, if there is no middle name, write - : " << endl;
		cin >> m;
	} while (x.legal_not_defined(m) || (x.legal_name(m)));
    
	do
	{
        cout << x.get_error() << endl;
		cout << "Enter a last name: " << endl;
		cin >> l;
	} while (x.legal_name(l));
    
	do
	{
        cout << x.get_error() << endl;
		cout << "Enter gender: " << endl;
		cin >> g;
	} while (x.legal_gender(g));
    
	do
	{
        cout << x.get_error() << endl;
		cout << "Enter year of birth: " << endl;
		cin >> y_o_b;
	} while (x.legal_year(y_o_b));
    
	do
	{
        cout << x.get_error() << endl;
		cout << "Enter year of death, if the person is alive, write - : " << endl;
		cin >> y_o_d;
	} while (x.legal_year(y_o_d) || (x.legal_not_defined(y_o_d)));
}

void input_search(string &s)
{
    cout << "Write search string: " << endl;
    cin >> s;
}


    
    
    
    
    
    
    
    
